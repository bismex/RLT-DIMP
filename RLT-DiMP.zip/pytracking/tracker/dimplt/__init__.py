from .dimplt import DiMPLT

def get_tracker_class():
    return DiMPLT