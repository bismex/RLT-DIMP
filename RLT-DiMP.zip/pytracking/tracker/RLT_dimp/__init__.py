from .RLT_dimp import RLT_dimp

def get_tracker_class():
    return RLT_dimp